This folder used to run some initial sql for clair if needed.

Just put the sql file in this directory and then start the
clair . 

both .sql and .gz format supported

